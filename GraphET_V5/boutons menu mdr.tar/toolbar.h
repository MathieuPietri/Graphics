#ifndef TOOLBAR_H
#define TOOLBAR_H

#include "ui_toolbar.h"

class ToolBar : public QMainWindow, private Ui::ToolBar
{
    Q_OBJECT

public:
    explicit ToolBar(QWidget *parent = nullptr);

protected slots:

    void tableauAleatoire();
};

#endif // TOOLBAR_H
