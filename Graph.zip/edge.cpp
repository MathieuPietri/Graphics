#include "graph.h"

Edge::Edge(Node *n1, Node *n2){
    _node1 = n1;
    _node2 = n2;
}