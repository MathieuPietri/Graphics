#include "graph.h"
using namespace std;

Node::Node(string id, int ponderation){
    _nameId = id;
    _ponderation = ponderation;
}